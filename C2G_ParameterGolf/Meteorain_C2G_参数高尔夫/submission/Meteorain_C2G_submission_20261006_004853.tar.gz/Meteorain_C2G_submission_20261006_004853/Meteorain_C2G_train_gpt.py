"""
C2G 参数高尔夫 —— 训练脚本
=========================
作者：07Meteorain (Meteorain)
基于：openai/parameter-golf `train_gpt.py` (Apache-2.0, 见 THIRD_PARTY_NOTICES.md)

硬约束（不可协商）：
  * 训练 wallclock <= 600s，评估 <= 600s（8xH100 SXM 口径）
  * artifact = 代码字节 + int8+zlib 压缩权重 <= 16,000,000 bytes（十进制 16MB）
  * 评估集FineWeb validation 不可在训练中访问
  * 指标 = BPB (bits-per-byte)，tokenizer 无关，越低越好

我的改动（每项均可通过环境变量单独关闭，用于消融实验）：
  A. SLIDING_WINDOW_EVAL  滑窗评估        —— PR #1204 / record 2026-03-19，实测 -0.0319 BPB
  B. FP16_EMBED_PASSTHROUGH fp16 嵌入直传  —— record 2026-03-18，把量化后BPB 退化从 ~0.007 压到 ~0.0005
  C. PARALLEL_RESIDUAL     并行残差        —— PR #1204/#1412，GPT-J 风格
  D. QK_GAIN_INIT          QK-gain 调优    —— record 2026-04-06 单调改进
  E. TUNED_LR_SCHEDULE     warmdown/LR 调优—— record 2026-03-18，10min 预算下默认schedule 假设步数过多

未采用的方案及理由见 docs/Meteorain_C2G_方案设计.md 的「否决清单」。
"""

from __future__ import annotations

import copy
import glob
import io
import json
import math
import os
import random
import subprocess
import sys
import time
import uuid
import zlib
from pathlib import Path

import numpy as np
import sentencepiece as spm
import torch
import torch.distributed as dist
import torch.nn.functional as F
from torch import Tensor, nn
from torch.nn.parallel import DistributedDataParallel as DDP


class Hyperparameters:
    """全部超参均可用环境变量覆盖，便于做扫描实验。"""

    # -----------------------------
    # 数据/路径
    # -----------------------------
    data_path = os.environ.get("DATA_PATH", "./data/datasets/fineweb10B_sp1024")
    train_files = os.path.join(data_path, "fineweb_train_*.bin")
    val_files = os.path.join(data_path, "fineweb_val_*.bin")
    tokenizer_path = os.environ.get(
        "TOKENIZER_PATH", "./data/tokenizers/fineweb_1024_bpe.model"
    )
    run_id = os.environ.get("RUN_ID", str(uuid.uuid4()))
    seed = int(os.environ.get("SEED", 1337))
    out_dir = os.environ.get("OUT_DIR", "./logs")

    # -----------------------------
    # 验证节奏
    # -----------------------------
    val_batch_size = int(os.environ.get("VAL_BATCH_SIZE", 524_288))
    val_loss_every = int(os.environ.get("VAL_LOSS_EVERY", 0))
    train_log_every = int(os.environ.get("TRAIN_LOG_EVERY", 200))
    # 0 = 用完整官方验证集（官方口径必须为 0）。
    # 本地单卡实验用它限制评估耗时，取验证集前缀，无选择偏差。
    max_val_tokens = int(os.environ.get("MAX_VAL_TOKENS", 0))

    # -----------------------------
    # 训练长度与预算
    # -----------------------------
    iterations = int(os.environ.get("ITERATIONS", 20000))
    warmdown_iters = int(os.environ.get("WARMDOWN_ITERS", 3600))
    warmup_steps = int(os.environ.get("WARMUP_STEPS", 5))
    train_batch_tokens = int(os.environ.get("TRAIN_BATCH_TOKENS", 524_288))
    train_seq_len = int(os.environ.get("TRAIN_SEQ_LEN", 1024))
    max_wallclock_seconds = float(os.environ.get("MAX_WALLCLOCK_SECONDS", 600.0))
    qk_gain_init = float(os.environ.get("QK_GAIN_INIT", 1.5))

    # -----------------------------
    # 模型形状
    # -----------------------------
    vocab_size = int(os.environ.get("VOCAB_SIZE", 1024))
    num_layers = int(os.environ.get("NUM_LAYERS", 9))
    num_kv_heads = int(os.environ.get("NUM_KV_HEADS", 4))
    model_dim = int(os.environ.get("MODEL_DIM", 512))
    num_heads = int(os.environ.get("NUM_HEADS", 8))
    mlp_mult = int(os.environ.get("MLP_MULT", 2))
    tie_embeddings = bool(int(os.environ.get("TIE_EMBEDDINGS", "1")))
    rope_base = float(os.environ.get("ROPE_BASE", 10000.0))
    logit_softcap = float(os.environ.get("LOGIT_SOFTCAP", 30.0))

    # -----------------------------
    # 改动开关（消融实验用）
    # -----------------------------
    # A. 滑窗评估
    sliding_window_eval = bool(int(os.environ.get("SLIDING_WINDOW_EVAL", "1")))
    eval_stride = int(os.environ.get("EVAL_STRIDE", 64))
    eval_batch_seqs = int(os.environ.get("EVAL_BATCH_SEQS", 32))
    # B. fp16 嵌入直传（跳过 int8 量化）
    fp16_embed_passthrough = bool(int(os.environ.get("FP16_EMBED_PASSTHROUGH", "1")))
    # C. 并行残差：从第几层开始 attention 与 MLP 读同一份输入
    parallel_residual = bool(int(os.environ.get("PARALLEL_RESIDUAL", "1")))
    parallel_residual_start = int(os.environ.get("PARALLEL_RESIDUAL_START", "7"))
    # E. LR 调优
    tuned_lr = bool(int(os.environ.get("TUNED_LR", "1")))

    # -----------------------------
    # 优化器
    # -----------------------------
    embed_lr = float(os.environ.get("EMBED_LR", 0.6))
    head_lr = float(os.environ.get("HEAD_LR", 0.008))
    tied_embed_lr = float(os.environ.get("TIED_EMBED_LR", 0.05))
    tied_embed_init_std = float(os.environ.get("TIED_EMBED_INIT_STD", 0.005))
    matrix_lr = float(os.environ.get("MATRIX_LR", 0.04))
    scalar_lr = float(os.environ.get("SCALAR_LR", 0.04))
    muon_momentum = float(os.environ.get("MUON_MOMENTUM", 0.95))
    muon_backend_steps = int(os.environ.get("MUON_BACKEND_STEPS", 5))
    muon_momentum_warmup_start = float(os.environ.get("MUON_MOMENTUM_WARMUP_START", 0.85))
    muon_momentum_warmup_steps = int(os.environ.get("MUON_MOMENTUM_WARMUP_STEPS", 500))
    beta1 = float(os.environ.get("BETA1", 0.9))
    beta2 = float(os.environ.get("BETA2", 0.95))
    adam_eps = float(os.environ.get("ADAM_EPS", 1e-8))
    grad_clip_norm = float(os.environ.get("GRAD_CLIP_NORM", 0.0))

    def __init__(self) -> None:
        # E. TUNED_LR 一次性生效：10 分钟预算下拿不到 20000 步，
        # 默认 warmdown=1200 会让 LR 在训练极早期就归零，收敛不充分。
        if self.tuned_lr:
            if "WARMDOWN_ITERS" not in os.environ:
                self.warmdown_iters = 3600
            if "MATRIX_LR" not in os.environ:
                self.matrix_lr = 0.06


# -----------------------------
# MUON OPTIMIZER（沿用 modded-nanoGPT / KellerJordan）
# 背景：https://kellerjordan.github.io/posts/muon/
# 原理：对 2D 梯度做 Newton-Schulz 迭代近似正交化（奇异值→1），
#      使更新方向只取决于矩阵形状而非梯度尺度，从而允许更大的 matrix LR。
# -----------------------------

def zeropower_via_newtonschulz5(G: Tensor, steps: int = 10, eps: float = 1e-7) -> Tensor:
    a, b, c = (3.4445, -4.7750, 2.0315)
    X = G.bfloat16()
    X /= X.norm() + eps
    transposed = G.size(0) > G.size(1)
    if transposed:
        X = X.T
    for _ in range(steps):
        A = X @ X.T
        B = b * A + c * A @ A
        X = a * X + B @ X
    return X.T if transposed else X


class Muon(torch.optim.Optimizer):
    """Muon：动量 + Newton-Schulz 正交化，按参数矩阵形状缩放更新量。

    分布式策略：把本 rank 负责的参数更新填进一个扁平 bf16 buffer，
    all_reduce 后每个 rank 都拿到完整更新，再写回各自的参数。
    这样每个参数只由一个 rank 计算正交化，避免重复计算，同时
    梯度在进入 buffer 前已由 DDP all-reduce 同步。
    """

    def __init__(self, params, lr: float, momentum: float, backend_steps: int, nesterov: bool = True):
        super().__init__(
            params,
            dict(lr=lr, momentum=momentum, backend_steps=backend_steps, nesterov=nesterov),
        )

    @torch.no_grad()
    def step(self, closure=None):
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        distributed = dist.is_available() and dist.is_initialized()
        world_size = dist.get_world_size() if distributed else 1
        rank = dist.get_rank() if distributed else 0

        for group in self.param_groups:
            params = group["params"]
            if not params:
                continue
            lr = group["lr"]
            momentum = group["momentum"]
            backend_steps = group["backend_steps"]
            nesterov = group["nesterov"]

            total_params = sum(int(p.numel()) for p in params)
            updates_flat = torch.zeros(total_params, device=params[0].device, dtype=torch.bfloat16)

            curr = 0
            for i, p in enumerate(params):
                if i % world_size == rank and p.grad is not None:
                    g = p.grad
                    state = self.state[p]
                    if "momentum_buffer" not in state:
                        state["momentum_buffer"] = torch.zeros_like(g)
                    buf = state["momentum_buffer"]
                    buf.mul_(momentum).add_(g)
                    if nesterov:
                        g = g.add(buf, alpha=momentum)
                    g = zeropower_via_newtonschulz5(g, steps=backend_steps)
                    # 形状缩放：让不同形状的矩阵有可比的有效步长
                    g *= max(1, g.size(0) / g.size(1)) ** 0.5
                    updates_flat[curr : curr + p.numel()] = g.reshape(-1)
                curr += p.numel()

            if distributed:
                dist.all_reduce(updates_flat, op=dist.ReduceOp.SUM)

            curr = 0
            for p in params:
                g = updates_flat[curr : curr + p.numel()].view_as(p).to(dtype=p.dtype)
                p.add_(g, alpha=-lr)
                curr += p.numel()

        return loss


# -----------------------------
# TOKENIZER-AGNOSTIC BPB 评估
#
# BPB =每字节消耗的比特数，与 tokenizer 无关，因此可以用不同 vocab 做公平比较。
# 关键：token 的"字节数"不等于 len(token)，因为 SentencePiece 的 "▁" 前缀
# 代表一个被合并进 token 的空格，必须计入目标 token 的字节数。
# -----------------------------

def build_sentencepiece_luts(
    sp: spm.SentencePieceProcessor, vocab_size: int, device: torch.device
) -> tuple[Tensor, Tensor, Tensor]:
    sp_vocab_size = int(sp.vocab_size())
    table_size = max(sp_vocab_size, vocab_size)
    base_bytes_np = np.zeros((table_size,), dtype=np.int16)
    has_leading_space_np = np.zeros((table_size,), dtype=np.bool_)
    is_boundary_token_np = np.ones((table_size,), dtype=np.bool_)
    for token_id in range(sp_vocab_size):
        if sp.is_control(token_id) or sp.is_unknown(token_id) or sp.is_unused(token_id):
            continue
        is_boundary_token_np[token_id] = False
        if sp.is_byte(token_id):
            base_bytes_np[token_id] = 1
            continue
        piece = sp.id_to_piece(token_id)
        if piece.startswith("\u2581"):
            has_leading_space_np[token_id] = True
            piece = piece[1:]
        base_bytes_np[token_id] = len(piece.encode("utf-8"))
    return (
        torch.tensor(base_bytes_np, dtype=torch.int16, device=device),
        torch.tensor(has_leading_space_np, dtype=torch.bool, device=device),
        torch.tensor(is_boundary_token_np, dtype=torch.bool, device=device),
    )


def load_validation_tokens(pattern: str, seq_len: int, max_tokens: int = 0) -> Tensor:
    """加载验证集。

    max_tokens > 0 时只取**前缀** max_tokens 个 token（官方验证集本身是冻结的
    前 50k 文档，取前缀不引入任何选择偏差）。官方 8xH100 口径下应保持 0（用全集），
    本地单卡实验用它控制评估耗时，必须在报告中注明实际使用的 token 数。
    """
    files = [Path(p) for p in sorted(glob.glob(pattern))]
    if not files:
        raise FileNotFoundError(f"No files found for pattern: {pattern}")
    tokens = torch.cat([load_data_shard(f) for f in files]).contiguous()
    if max_tokens > 0:
        tokens = tokens[: max_tokens + 1]
    usable = ((tokens.numel() - 1) // seq_len) * seq_len
    if usable <= 0:
        raise ValueError(f"Validation split too short for TRAIN_SEQ_LEN={seq_len}")
    return tokens[: usable + 1]


def _score_from_luts(
    nll: Tensor,
    prev_ids: Tensor,
    tgt_ids: Tensor,
    base_bytes_lut: Tensor,
    has_leading_space_lut: Tensor,
    is_boundary_token_lut: Tensor,
) -> tuple[Tensor, Tensor, Tensor]:
    """把 token 级 NLL 折算成 BPB 所需的三个累加量。

    字节数规则（与官方 eval 一致）：
      bytes(t) = base_bytes(t) + (t 带前导空格 且 上一 token 不是文档边界)
    上一 token 若是边界（文档/片段起始），那个空格属于上一个文档，不能算在本 token 上。
    """
    token_bytes = base_bytes_lut[tgt_ids].to(torch.float64)
    token_bytes += (
        has_leading_space_lut[tgt_ids] & ~is_boundary_token_lut[prev_ids]
    ).to(torch.float64)
    return nll.sum(), token_bytes.sum(), tgt_ids.numel()


def eval_val_chunked(
    args: Hyperparameters,
    model: nn.Module,
    rank: int,
    world_size: int,
    device: torch.device,
    grad_accum_steps: int,
    val_tokens: Tensor,
    base_bytes_lut: Tensor,
    has_leading_space_lut: Tensor,
    is_boundary_token_lut: Tensor,
) -> tuple[float, float]:
    """基线评估：把验证集切成互不重叠的 seq_len 块。

    每个块的首token 没有任何上下文，平均每个 token 只有 ~512 个上下文 token。
    这是 baseline 1.2244 的来源。
    """
    local_batch_tokens = args.val_batch_size // (world_size * grad_accum_steps)
    if local_batch_tokens < args.train_seq_len:
        raise ValueError(
            f"VAL_BATCH_SIZE={args.val_batch_size} too small for world_size={world_size}, "
            f"grad_accum={grad_accum_steps}, seq_len={args.train_seq_len}"
        )
    local_batch_seqs = local_batch_tokens // args.train_seq_len
    total_seqs = (val_tokens.numel() - 1) // args.train_seq_len
    seq_start = (total_seqs * rank) // world_size
    seq_end = (total_seqs * (rank + 1)) // world_size

    loss_sum = torch.zeros((), device=device, dtype=torch.float64)
    token_count = torch.zeros((), device=device, dtype=torch.float64)
    byte_count = torch.zeros((), device=device, dtype=torch.float64)

    model.eval()
    with torch.inference_mode():
        for s in range(seq_start, seq_end, local_batch_seqs):
            e = min(s + local_batch_seqs, seq_end)
            raw_s = s * args.train_seq_len
            raw_e = e * args.train_seq_len + 1
            local = val_tokens[raw_s:raw_e].to(device=device, dtype=torch.int64, non_blocking=True)
            x = local[:-1].reshape(-1, args.train_seq_len)
            y = local[1:].reshape(-1, args.train_seq_len)
            with torch.autocast(device_type="cuda", dtype=torch.bfloat16, enabled=True):
                batch_loss = model(x, y).detach()
            n = float(y.numel())
            loss_sum += batch_loss.to(torch.float64) * n
            token_count += n
            prev_ids = x.reshape(-1)
            tgt_ids = y.reshape(-1)
            token_bytes = base_bytes_lut[tgt_ids].to(torch.float64)
            token_bytes += (
                has_leading_space_lut[tgt_ids] & ~is_boundary_token_lut[prev_ids]
            ).to(torch.float64)
            byte_count += token_bytes.sum()

    if dist.is_available() and dist.is_initialized():
        dist.all_reduce(loss_sum, op=dist.ReduceOp.SUM)
        dist.all_reduce(token_count, op=dist.ReduceOp.SUM)
        dist.all_reduce(byte_count, op=dist.ReduceOp.SUM)

    val_loss = (loss_sum / token_count).item()
    bits_per_token = val_loss / math.log(2.0)
    tokens_per_byte = token_count.item() / byte_count.item()
    model.train()
    return val_loss, bits_per_token * tokens_per_byte


def eval_val_sliding(
    args: Hyperparameters,
    base_model: nn.Module,
    rank: int,
    world_size: int,
    device: torch.device,
    val_tokens: Tensor,
    base_bytes_lut: Tensor,
    has_leading_space_lut: Tensor,
    is_boundary_token_lut: Tensor,
) -> tuple[float, float]:
    """滑窗评估（改动 A）：每个 token 都用接近最大上下文来打分。

    做法：窗口长度=train_seq_len，但每次只前进 stride 个 token，
    且只对最右边 stride 个 token 计分（它们已累积 seq_len-stride 个上下文）。
    每个 token 恰好被计分一次，不重不漏，因此是合法的因果评估。

    代价：窗口数 = total_tokens / stride，是 chunked 的 seq_len/stride 倍计算量。
    收益：官方实测 -0.0319 BPB（record 2026-03-19_SlidingWindowEval）。
    """
    seq_len = args.train_seq_len
    stride = args.eval_stride
    total_tokens = val_tokens.numel() - 1

    window_starts = [ws for ws in range(0, total_tokens, stride) if min(ws + seq_len, total_tokens) - ws >= 1]
    total_windows = len(window_starts)
    my_s = (total_windows * rank) // world_size
    my_e = (total_windows * (rank + 1)) // world_size
    my_windows = window_starts[my_s:my_e]

    loss_sum = torch.zeros((), device=device, dtype=torch.float64)
    token_count = torch.zeros((), device=device, dtype=torch.float64)
    byte_count = torch.zeros((), device=device, dtype=torch.float64)

    base_model.eval()
    with torch.inference_mode():
        for bi in range(0, len(my_windows), args.eval_batch_seqs):
            batch_ws = my_windows[bi : bi + args.eval_batch_seqs]
            bsz = len(batch_ws)
            x_batch = torch.zeros(bsz, seq_len, dtype=torch.int64, device=device)
            y_batch = torch.zeros(bsz, seq_len, dtype=torch.int64, device=device)
            wlens: list[int] = []

            for i, ws in enumerate(batch_ws):
                end = min(ws + seq_len, total_tokens)
                wlen = end - ws
                wlens.append(wlen)
                chunk = val_tokens[ws : end + 1].to(dtype=torch.int64, device=device)
                x_batch[i, :wlen] = chunk[:-1]
                y_batch[i, :wlen] = chunk[1:]

            with torch.autocast(device_type="cuda", dtype=torch.bfloat16, enabled=True):
                logits = base_model.forward_logits(x_batch)

            nll = F.cross_entropy(
                logits.reshape(-1, logits.size(-1)).float(),
                y_batch.reshape(-1),
                reduction="none",
            ).reshape(bsz, seq_len)

            for i, ws in enumerate(batch_ws):
                wlen = wlens[i]
                # 第一个窗口从0 开始计分（没有前一个窗口可以承接）；之后的窗口
                # 只计分最右边 stride 个 token，左边的部分已经计过分了。
                s = 0 if ws == 0 else max(wlen - stride, 0)
                nll_i = nll[i, s:wlen].to(torch.float64)
                tgt = y_batch[i, s:wlen]
                prev = x_batch[i, s:wlen]
                loss_sum += nll_i.sum()
                token_count += float(wlen - s)
                tb = base_bytes_lut[tgt].to(torch.float64)
                tb += (has_leading_space_lut[tgt] & ~is_boundary_token_lut[prev]).to(torch.float64)
                byte_count += tb.sum()

            if rank == 0 and (bi // args.eval_batch_seqs) % 100 == 0 and len(my_windows) > 0:
                done = min(bi + args.eval_batch_seqs, len(my_windows))
                running = 0.0
                if token_count.item() > 0:
                    running = (loss_sum / token_count).item() / math.log(2.0) * (
                        token_count.item() / byte_count.item()
                    )
                print(
                    f"  sliding_eval [{done / len(my_windows) * 100:5.1f}%] "
                    f"{done}/{len(my_windows)} windows running_bpb={running:.6f}",
                    flush=True,
                )

    if dist.is_available() and dist.is_initialized():
        dist.all_reduce(loss_sum, op=dist.ReduceOp.SUM)
        dist.all_reduce(token_count, op=dist.ReduceOp.SUM)
        dist.all_reduce(byte_count, op=dist.ReduceOp.SUM)

    val_loss = (loss_sum / token_count).item()
    bits_per_token = val_loss / math.log(2.0)
    tokens_per_byte = token_count.item() / byte_count.item()
    base_model.train()
    return val_loss, bits_per_token * tokens_per_byte


# -----------------------------
# POST-TRAINING QUANTIZATION
#
# artifact 预算 = 代码字节 + 压缩后权重字节。
# 模型 bf16/fp32 存不下，必须量化。官方用 per-row int8 + zlib(level 9)。
#
# 改动 B：嵌入层是最敏感的张量 —— 它同时充当 embedding 和 output head
# （tied embeddings），角色双重导致误差直接放大到 logits 上。
# 把它以 fp16 直传（不量化），实测把量化后 BPB 退化从 ~0.007 压到 ~0.0005，
# 代价约 500KB artifact 空间。
# -----------------------------

CONTROL_TENSOR_NAME_PATTERNS = tuple(
    p
    for p in os.environ.get(
        "CONTROL_TENSOR_NAME_PATTERNS",
        "attn_scale,attn_scales,mlp_scale,mlp_scales,resid_mix,resid_mixes,q_gain,skip_weight,skip_weights",
    ).split(",")
    if p
)
INT8_KEEP_FLOAT_FP32_NAME_PATTERNS = tuple(
    p
    for p in os.environ.get(
        "INT8_KEEP_FLOAT_FP32_NAME_PATTERNS", ",".join(CONTROL_TENSOR_NAME_PATTERNS)
    ).split(",")
    if p
)
INT8_KEEP_FLOAT_MAX_NUMEL = 65_536
INT8_KEEP_FLOAT_STORE_DTYPE = torch.float16
INT8_PER_ROW_SCALE_DTYPE = torch.float16
INT8_CLIP_PERCENTILE = 99.99984
INT8_CLIP_Q = INT8_CLIP_PERCENTILE / 100.0

# 改动 B 的白名单：这些张量以 fp16 直传，不做 int8 量化
FP16_PASSTHROUGH_PATTERNS = tuple(
    p for p in os.environ.get("FP16_PASSTHROUGH_PATTERNS", "tok_emb").split(",") if p
)


def tensor_nbytes(t: Tensor) -> int:
    return int(t.numel()) * int(t.element_size())


def keep_float_tensor(name: str, t: Tensor, passthrough_orig_dtypes: dict[str, str]) -> Tensor:
    if any(pattern in name for pattern in INT8_KEEP_FLOAT_FP32_NAME_PATTERNS):
        return t.float().contiguous()
    if t.dtype in {torch.float32, torch.bfloat16}:
        passthrough_orig_dtypes[name] = str(t.dtype).removeprefix("torch.")
        return t.to(dtype=INT8_KEEP_FLOAT_STORE_DTYPE).contiguous()
    return t


def quantize_float_tensor(t: Tensor) -> tuple[Tensor, Tensor]:
    t32 = t.float()
    if t32.ndim == 2:
        # 2D 矩阵按行（输出通道）一个scale：不同输出通道的动态范围差别很大，
        # 单个 tensor 级 scale 会浪费码字。
        clip_abs = (
            torch.quantile(t32.abs(), INT8_CLIP_Q, dim=1)
            if t32.numel()
            else torch.empty((t32.shape[0],), dtype=torch.float32)
        )
        clipped = torch.maximum(torch.minimum(t32, clip_abs[:, None]), -clip_abs[:, None])
        scale = (clip_abs / 127.0).clamp_min(1.0 / 127.0)
        q = torch.clamp(torch.round(clipped / scale[:, None]), -127, 127).to(torch.int8).contiguous()
        return q, scale.to(dtype=INT8_PER_ROW_SCALE_DTYPE).contiguous()

    clip_abs = float(torch.quantile(t32.abs().flatten(), INT8_CLIP_Q).item()) if t32.numel() else 0.0
    scale = torch.tensor(clip_abs / 127.0 if clip_abs > 0 else 1.0, dtype=torch.float32)
    q = torch.clamp(torch.round(torch.clamp(t32, -clip_abs, clip_abs) / scale), -127, 127).to(torch.int8).contiguous()
    return q, scale


def quantize_state_dict_int8(state_dict: dict[str, Tensor], fp16_passthrough: bool = True):
    """把 state_dict 量化成 int8 + zlib 可压缩格式。

    fp16_passthrough=True 时，匹配 FP16_PASSTHROUGH_PATTERNS 的张量（如 tok_emb）
    以 fp16 原样保留，不走 int8 量化路径。
    """
    quantized: dict[str, Tensor] = {}
    scales: dict[str, Tensor] = {}
    dtypes: dict[str, str] = {}
    passthrough: dict[str, Tensor] = {}
    passthrough_orig_dtypes: dict[str, str] = {}
    qmeta: dict[str, dict[str, object]] = {}
    stats = dict.fromkeys(
        ("param_count", "num_tensors", "num_float_tensors", "num_nonfloat_tensors",
         "baseline_tensor_bytes", "int8_payload_bytes", "fp16_passthrough_bytes"),
        0,
    )

    for name, tensor in state_dict.items():
        t = tensor.detach().to("cpu").contiguous()
        stats["param_count"] += int(t.numel())
        stats["num_tensors"] += 1
        stats["baseline_tensor_bytes"] += tensor_nbytes(t)

        if not t.is_floating_point():
            stats["num_nonfloat_tensors"] += 1
            passthrough[name] = t
            stats["int8_payload_bytes"] += tensor_nbytes(t)
            continue

        # 改动 B：fp16 直传
        if fp16_passthrough and any(p in name for p in FP16_PASSTHROUGH_PATTERNS):
            passthrough[name] = t.to(dtype=torch.float16).contiguous()
            passthrough_orig_dtypes[name] = str(t.dtype).removeprefix("torch.")
            stats["fp16_passthrough_bytes"] += tensor_nbytes(passthrough[name])
            stats["int8_payload_bytes"] += tensor_nbytes(passthrough[name])
            continue

        # 小张量直接保留（量化误差大于存储收益）
        if t.numel() <= INT8_KEEP_FLOAT_MAX_NUMEL:
            kept = keep_float_tensor(name, t, passthrough_orig_dtypes)
            passthrough[name] = kept
            stats["int8_payload_bytes"] += tensor_nbytes(kept)
            continue

        stats["num_float_tensors"] += 1
        q, s = quantize_float_tensor(t)
        if s.ndim > 0:
            qmeta[name] = {"scheme": "per_row", "axis": 0}
        quantized[name] = q
        scales[name] = s
        dtypes[name] = str(t.dtype).removeprefix("torch.")
        stats["int8_payload_bytes"] += tensor_nbytes(q) + tensor_nbytes(s)

    obj: dict[str, object] = {
        "__quant_format__": "int8_clean_per_row_v1",
        "quantized": quantized,
        "scales": scales,
        "dtypes": dtypes,
        "passthrough": passthrough,
    }
    if qmeta:
        obj["qmeta"] = qmeta
    if passthrough_orig_dtypes:
        obj["passthrough_orig_dtypes"] = passthrough_orig_dtypes
    return obj, stats


def dequantize_state_dict_int8(obj: dict[str, object]) -> dict[str, Tensor]:
    out: dict[str, Tensor] = {}
    qmeta = obj.get("qmeta", {})
    passthrough_orig_dtypes = obj.get("passthrough_orig_dtypes", {})
    for name, q in obj["quantized"].items():
        dtype = getattr(torch, obj["dtypes"][name])
        s = obj["scales"][name]
        if qmeta.get(name, {}).get("scheme") == "per_row" or s.ndim > 0:
            s = s.to(dtype=torch.float32)
            out[name] = (q.float() * s.view(q.shape[0], *([1] * (q.ndim - 1)))).to(dtype=dtype).contiguous()
        else:
            scale = float(s.item())
            out[name] = (q.float() * scale).to(dtype=dtype).contiguous()
    for name, t in obj["passthrough"].items():
        out_t = t.detach().to("cpu").contiguous()
        orig_dtype = passthrough_orig_dtypes.get(name)
        if isinstance(orig_dtype, str):
            out_t = out_t.to(dtype=getattr(torch, orig_dtype)).contiguous()
        out[name] = out_t
    return out


# -----------------------------
# DATA LOADING
# .bin 格式：256 个 int32 的header（magic=20240520, version=1, num_tokens），
# 之后是 num_tokens 个 uint16 token。
# -----------------------------

def load_data_shard(file: Path) -> Tensor:
    header_bytes = 256 * np.dtype("<i4").itemsize
    token_bytes = np.dtype("<u2").itemsize
    header = np.fromfile(file, dtype="<i4", count=256)
    if header.size != 256 or int(header[0]) != 20240520 or int(header[1]) != 1:
        raise ValueError(f"Unexpected shard header for {file}")
    num_tokens = int(header[2])
    expected_size = header_bytes + num_tokens * token_bytes
    if file.stat().st_size != expected_size:
        raise ValueError(f"Shard size mismatch for {file}: expected {expected_size} bytes")
    tokens_np = np.fromfile(file, dtype="<u2", count=num_tokens, offset=header_bytes)
    if tokens_np.size != num_tokens:
        raise ValueError(f"Short read for {file}")
    return torch.from_numpy(tokens_np.astype(np.uint16, copy=False))


class TokenStream:
    """顺序读shard，读完一个接下一个，循环使用。无采样、无shuffle。"""

    def __init__(self, pattern: str):
        self.files = [Path(p) for p in sorted(glob.glob(pattern))]
        if not self.files:
            raise FileNotFoundError(f"No files found for pattern: {pattern}")
        self.file_idx = 0
        self.tokens = load_data_shard(self.files[0])
        self.pos = 0

    def _advance_file(self) -> None:
        self.file_idx = (self.file_idx + 1) % len(self.files)
        self.tokens = load_data_shard(self.files[self.file_idx])
        self.pos = 0

    def take(self, n: int) -> Tensor:
        chunks: list[Tensor] = []
        remaining = n
        while remaining > 0:
            avail = self.tokens.numel() - self.pos
            if avail <= 0:
                self._advance_file()
                continue
            k = min(remaining, avail)
            chunks.append(self.tokens[self.pos : self.pos + k])
            self.pos += k
            remaining -= k
        return chunks[0] if len(chunks) == 1 else torch.cat(chunks)


class DistributedTokenLoader:
    """每个 rank 从共享流里取一段互不重叠的 span。

    多取 1 个 token 用于构造 (x, y) = (t[:-1], t[1:])。
    """

    def __init__(self, pattern: str, rank: int, world_size: int, device: torch.device):
        self.rank = rank
        self.world_size = world_size
        self.device = device
        self.stream = TokenStream(pattern)

    def next_batch(self, global_tokens: int, seq_len: int, grad_accum_steps: int) -> tuple[Tensor, Tensor]:
        local_tokens = global_tokens // (self.world_size * grad_accum_steps)
        per_rank_span = local_tokens + 1
        chunk = self.stream.take(per_rank_span * self.world_size)
        start = self.rank * per_rank_span
        local = chunk[start : start + per_rank_span].to(dtype=torch.int64)
        x = local[:-1].reshape(-1, seq_len)
        y = local[1:].reshape(-1, seq_len)
        return x.to(self.device, non_blocking=True), y.to(self.device, non_blocking=True)


# -----------------------------
# TRANSFORMER MODULES
# -----------------------------

class RMSNorm(nn.Module):
    def __init__(self, eps: float | None = None):
        super().__init__()
        self.eps = eps

    def forward(self, x: Tensor) -> Tensor:
        return F.rms_norm(x, (x.size(-1),), eps=self.eps)


class CastedLinear(nn.Linear):
    """权重存fp32（优化器状态质量），matmul 时转 bf16。

    优化器对 bf16 参数的状态精度不够，跑Muon/Adam 都容易不稳。
    """

    def forward(self, x: Tensor) -> Tensor:
        bias = self.bias.to(x.dtype) if self.bias is not None else None
        return F.linear(x, self.weight.to(x.dtype), bias)


def restore_low_dim_params_to_fp32(module: nn.Module) -> None:
    """把低维/控制参数留在 fp32，即使模型主体跑 bf16。

    这些参数数量少但直接决定残差混合比例，bf16 的舍入误差会持续累积。
    """
    with torch.no_grad():
        for name, param in module.named_parameters():
            if (param.ndim < 2 or any(p in name for p in CONTROL_TENSOR_NAME_PATTERNS)) and param.dtype != torch.float32:
                param.data = param.data.float()


class Rotary(nn.Module):
    """RoPE：按位置旋转 q/k 的二维分量，把相对位置信息注入注意力。

    cos/sin 表按 seq_len 缓存，避免每步重算。
    """

    def __init__(self, dim: int, base: float = 10000.0):
        super().__init__()
        inv_freq = 1.0 / (base ** (torch.arange(0, dim, 2, dtype=torch.float32) / dim))
        self.register_buffer("inv_freq", inv_freq, persistent=False)
        self._seq_len_cached = 0
        self._cos_cached: Tensor | None = None
        self._sin_cached: Tensor | None = None

    def forward(self, seq_len: int, device: torch.device, dtype: torch.dtype) -> tuple[Tensor, Tensor]:
        if (
            self._cos_cached is None
            or self._sin_cached is None
            or self._seq_len_cached != seq_len
            or self._cos_cached.device != device
        ):
            t = torch.arange(seq_len, device=device, dtype=self.inv_freq.dtype)
            freqs = torch.outer(t, self.inv_freq.to(device))
            self._cos_cached = freqs.cos()[None, None, :, :]
            self._sin_cached = freqs.sin()[None, None, :, :]
            self._seq_len_cached = seq_len
        return self._cos_cached.to(dtype=dtype), self._sin_cached.to(dtype=dtype)


def apply_rotary_emb(x: Tensor, cos: Tensor, sin: Tensor) -> Tensor:
    half = x.size(-1) // 2
    x1, x2 = x[..., :half], x[..., half:]
    return torch.cat((x1 * cos + x2 * sin, x1 * (-sin) + x2 * cos), dim=-1)


# GQA 有两种实现方式：
#   1) fused：enable_gqa=True，由SDPA 内部把 kv head 广播到 q head 数（快、省显存）
#   2) expand：手动 repeat_interleave 展开 kv（所有后端都支持，稍慢但通用）
# 官方 8xH100 上 fused 可用；但部分构建/架构（如 head_dim=32 + sm_86）下
# fused kernel 不支持 head 广播，会报 "No available kernel"。
# 因此这里在启动时探测一次，fused 不可用就自动降级为 expand，两者数学上完全等价。
GQA_IMPL = os.environ.get("GQA_IMPL", "auto")  # auto | fused | expand


def probe_fused_gqa(device: torch.device, num_heads: int, num_kv_heads: int, head_dim: int) -> bool:
    """探测当前设备/构建是否支持 fused GQA 内核。失败则返回 False。"""
    try:
        q = torch.randn(1, num_heads, 8, head_dim, device=device, dtype=torch.bfloat16)
        k = torch.randn(1, num_kv_heads, 8, head_dim, device=device, dtype=torch.bfloat16)
        v = torch.randn(1, num_kv_heads, 8, head_dim, device=device, dtype=torch.bfloat16)
        out = F.scaled_dot_product_attention(q, k, v, is_causal=True, enable_gqa=True)
        return out.shape == q.shape
    except Exception:
        return False


class CausalSelfAttention(nn.Module):
    """GQA + QK-RMSNorm + QK-gain + RoPE。

    两个细节值得说明：
    1. q/k 在 RoPE 前各自做 RMSNorm —— 这是 QK-Norm，防止 attention logits
       在大模型里随训练发散（logits 爆炸 → softmax 饱和 → 梯度消失）。
    2. q_gain 是可学习的 per-head 缩放。注意力 logit 的整体尺度直接决定
       softmax 的锐度；把它交给模型自己学，比固定值更稳（PR #1204）。
    """

    def __init__(
        self,
        dim: int,
        num_heads: int,
        num_kv_heads: int,
        rope_base: float,
        qk_gain_init: float,
    ):
        super().__init__()
        if dim % num_heads != 0:
            raise ValueError("model_dim must be divisible by num_heads")
        if num_heads % num_kv_heads != 0:
            raise ValueError("num_heads must be divisible by num_kv_heads")
        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads
        self.head_dim = dim // num_heads
        if self.head_dim % 2 != 0:
            raise ValueError("head_dim must be even for RoPE")
        kv_dim = self.num_kv_heads * self.head_dim
        self.c_q = CastedLinear(dim, dim, bias=False)
        self.c_k = CastedLinear(dim, kv_dim, bias=False)
        self.c_v = CastedLinear(dim, kv_dim, bias=False)
        self.proj = CastedLinear(dim, dim, bias=False)
        self.proj._zero_init = True
        self.q_gain = nn.Parameter(torch.full((num_heads,), qk_gain_init, dtype=torch.float32))
        self.rotary = Rotary(self.head_dim, base=rope_base)

    def forward(self, x: Tensor) -> Tensor:
        bsz, seqlen, dim = x.shape
        q = self.c_q(x).reshape(bsz, seqlen, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.c_k(x).reshape(bsz, seqlen, self.num_kv_heads, self.head_dim).transpose(1, 2)
        v = self.c_v(x).reshape(bsz, seqlen, self.num_kv_heads, self.head_dim).transpose(1, 2)
        q = F.rms_norm(q, (q.size(-1),))
        k = F.rms_norm(k, (k.size(-1),))
        cos, sin = self.rotary(seqlen, x.device, q.dtype)
        q = apply_rotary_emb(q, cos, sin)
        k = apply_rotary_emb(k, cos, sin)
        q = q * self.q_gain.to(dtype=q.dtype)[None, :, None, None]
        # GQA：q 的 head 数是 kv 的整数倍。fused 不可用时手动展开（数学等价）。
        if self.num_kv_heads != self.num_heads and GQA_IMPL == "expand":
            rep = self.num_heads // self.num_kv_heads
            k = k.repeat_interleave(rep, dim=1)
            v = v.repeat_interleave(rep, dim=1)
            y = F.scaled_dot_product_attention(q, k, v, attn_mask=None, is_causal=True)
        else:
            y = F.scaled_dot_product_attention(
                q,
                k,
                v,
                attn_mask=None,
                is_causal=True,
                enable_gqa=(self.num_kv_heads != self.num_heads),
            )
        y = y.transpose(1, 2).contiguous().reshape(bsz, seqlen, dim)
        return self.proj(y)


class MLP(nn.Module):
    """relu^2 MLP（modded-nanogpt 原版）。

    relu(x)^2 而非普通 relu：平方让激活分布的尾部更重，
    相当于给 MLP 增加了非线性表达力，参数量不变。
    """

    def __init__(self, dim: int, mlp_mult: int):
        super().__init__()
        hidden = mlp_mult * dim
        self.fc = CastedLinear(dim, hidden, bias=False)
        self.proj = CastedLinear(hidden, dim, bias=False)
        self.proj._zero_init = True

    def forward(self, x: Tensor) -> Tensor:
        x = torch.relu(self.fc(x))
        return self.proj(x.square())


class Block(nn.Module):
    """Transformer block，支持串行残差与并行残差两种模式（改动 C）。

    串行（默认）：
        x = x + attn(attn_norm(x))
        x = x + mlp(mlp_norm(x))

    并行（PARALLEL_RESIDUAL 且 layer_idx >= start）：
        h = x
        x = x + attn(attn_norm(h))
        x = x + mlp(mlp_norm(h))

    并行残差让attention 和 MLP 读同一份输入，梯度路径更直接，
    深层网络里信号传播更顺畅（GPT-J 提出，PR #1204/#1412 采用）。
    """

    def __init__(
        self,
        dim: int,
        num_heads: int,
        num_kv_heads: int,
        mlp_mult: int,
        rope_base: float,
        qk_gain_init: float,
        layer_idx: int = 0,
        parallel_residual: bool = False,
        parallel_residual_start: int = 7,
    ):
        super().__init__()
        self.layer_idx = layer_idx
        self.attn_norm = RMSNorm()
        self.mlp_norm = RMSNorm()
        self.attn = CausalSelfAttention(dim, num_heads, num_kv_heads, rope_base, qk_gain_init)
        self.mlp = MLP(dim, mlp_mult)
        self.attn_scale = nn.Parameter(torch.ones(dim, dtype=torch.float32))
        self.mlp_scale = nn.Parameter(torch.ones(dim, dtype=torch.float32))
        self.resid_mix = nn.Parameter(torch.stack((torch.ones(dim), torch.zeros(dim))).float())
        self.parallel = parallel_residual and layer_idx >= parallel_residual_start

    def forward(self, x: Tensor, x0: Tensor) -> Tensor:
        mix = self.resid_mix.to(dtype=x.dtype)
        x = mix[0][None, None, :] * x + mix[1][None, None, :] * x0
        if self.parallel:
            h = x
            x = x + self.attn_scale.to(dtype=x.dtype)[None, None, :] * self.attn(self.attn_norm(h))
            x = x + self.mlp_scale.to(dtype=x.dtype)[None, None, :] * self.mlp(self.mlp_norm(h))
        else:
            x = x + self.attn_scale.to(dtype=x.dtype)[None, None, :] * self.attn(self.attn_norm(x))
            x = x + self.mlp_scale.to(dtype=x.dtype)[None, None, :] * self.mlp(self.mlp_norm(x))
        return x


class GPT(nn.Module):
    """U-Net 式skip 连接的 decoder-only Transformer。

    前半层把中间结果存进 skips，后半层按相反顺序取回并加回。
    这让浅层细节可以直接抵达深层，避免深层只能看到高度抽象的表示。
    """

    def __init__(
        self,
        vocab_size: int,
        num_layers: int,
        model_dim: int,
        num_heads: int,
        num_kv_heads: int,
        mlp_mult: int,
        tie_embeddings: bool,
        tied_embed_init_std: float,
        logit_softcap: float,
        rope_base: float,
        qk_gain_init: float,
        parallel_residual: bool = False,
        parallel_residual_start: int = 7,
    ):
        super().__init__()
        if logit_softcap <= 0.0:
            raise ValueError(f"logit_softcap must be positive, got {logit_softcap}")
        self.tie_embeddings = tie_embeddings
        self.tied_embed_init_std = tied_embed_init_std
        self.logit_softcap = logit_softcap
        self.tok_emb = nn.Embedding(vocab_size, model_dim)
        self.num_encoder_layers = num_layers // 2
        self.num_decoder_layers = num_layers - self.num_encoder_layers
        self.num_skip_weights = min(self.num_encoder_layers, self.num_decoder_layers)
        self.skip_weights = nn.Parameter(torch.ones(self.num_skip_weights, model_dim, dtype=torch.float32))
        self.blocks = nn.ModuleList(
            [
                Block(
                    model_dim,
                    num_heads,
                    num_kv_heads,
                    mlp_mult,
                    rope_base,
                    qk_gain_init,
                    layer_idx=i,
                    parallel_residual=parallel_residual,
                    parallel_residual_start=parallel_residual_start,
                )
                for i in range(num_layers)
            ]
        )
        self.final_norm = RMSNorm()
        self.lm_head = None if tie_embeddings else CastedLinear(model_dim, vocab_size, bias=False)
        if self.lm_head is not None:
            self.lm_head._zero_init = True
        self._init_weights()

    def _init_weights(self) -> None:
        if self.tie_embeddings:
            nn.init.normal_(self.tok_emb.weight, mean=0.0, std=self.tied_embed_init_std)
        for module in self.modules():
            if isinstance(module, nn.Linear) and getattr(module, "_zero_init", False):
                nn.init.zeros_(module.weight)

    def forward(self, input_ids: Tensor, target_ids: Tensor) -> Tensor:
        logits = self.forward_logits(input_ids)
        return F.cross_entropy(logits.float(), target_ids.reshape(-1), reduction="mean")

    def forward_logits(self, input_ids: Tensor) -> Tensor:
        x = self.tok_emb(input_ids)
        x = F.rms_norm(x, (x.size(-1),))
        x0 = x
        skips: list[Tensor] = []
        for i in range(self.num_encoder_layers):
            x = self.blocks[i](x, x0)
            skips.append(x)
        for i in range(self.num_decoder_layers):
            if skips:
                x = x + self.skip_weights[i].to(dtype=x.dtype)[None, None, :] * skips.pop()
            x = self.blocks[self.num_encoder_layers + i](x, x0)

        x = self.final_norm(x).reshape(-1, x.size(-1))
        if self.tie_embeddings:
            logits_proj = F.linear(x, self.tok_emb.weight)
        else:
            if self.lm_head is None:
                raise RuntimeError("lm_head is required when tie_embeddings=False")
            logits_proj = self.lm_head(x)
        # softcap：限制 logits 幅度，防止个别 token 的 logit 过大主导 softmax
        return self.logit_softcap * torch.tanh(logits_proj / self.logit_softcap)


# -----------------------------
# TRAINING
# -----------------------------

def main() -> None:
    global zeropower_via_newtonschulz5
    global GQA_IMPL

    code = Path(__file__).read_text(encoding="utf-8")
    args = Hyperparameters()

    # torch.compile / inductor 需要 Triton。官方 8xH100 (Linux) 环境自带，
    # 但 Windows 本地环境没有，会让编译直接失败。
    # 这里按 USE_COMPILE 开关决定是否编译；关闭时走 eager，功能完全一致，
    # 只是慢一些——这对「验证方法论」无影响，因为所有实验用固定步数做等算力对照。
    use_compile = bool(int(os.environ.get("USE_COMPILE", "1")))
    if use_compile:
        try:
            zeropower_via_newtonschulz5 = torch.compile(zeropower_via_newtonschulz5)
        except Exception as exc:  # pragma: no cover
            print(f"[warn] torch.compile(zeropower) unavailable: {exc}", flush=True)
            use_compile = False

    # -----------------------------
    # DISTRIBUTED + CUDA SETUP
    # -----------------------------
    distributed = "RANK" in os.environ and "WORLD_SIZE" in os.environ
    rank = int(os.environ.get("RANK", "0"))
    world_size = int(os.environ.get("WORLD_SIZE", "1"))
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    if world_size <= 0:
        raise ValueError(f"WORLD_SIZE must be positive, got {world_size}")
    if 8 % world_size != 0:
        raise ValueError(f"WORLD_SIZE={world_size} must divide 8 so grad_accum_steps stays integral")
    grad_accum_steps = 8 // world_size
    grad_scale = 1.0 / grad_accum_steps
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    device = torch.device("cuda", local_rank)
    torch.cuda.set_device(device)
    if distributed:
        dist.init_process_group(backend="nccl", device_id=device)
        dist.barrier()
    master_process = rank == 0

    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True
    from torch.backends.cuda import enable_cudnn_sdp, enable_flash_sdp, enable_math_sdp, enable_mem_efficient_sdp

    # 官方脚本在 8xH100 (sm_90) 上只开 flash。但 flash kernel 对 head_dim
    # 和GPU 架构有要求（例如 head_dim=32 + sm_86 无可用 kernel），
    # 直接沿用会在非 H100 机器上崩。这里按可用性依次回退，
    # 并允许用 SDPA_BACKENDS 环境变量强制指定，保证换机器仍能跑。
    _forced = os.environ.get("SDPA_BACKENDS", "").strip()
    if _forced:
        enable_cudnn_sdp("cudnn" in _forced)
        enable_flash_sdp("flash" in _forced)
        enable_mem_efficient_sdp("mem_efficient" in _forced)
        enable_math_sdp("math" in _forced)
        sdp_desc = _forced
    else:
        enable_cudnn_sdp(False)
        enable_flash_sdp(True)
        enable_mem_efficient_sdp(True)
        enable_math_sdp(True)
        sdp_desc = "flash_first_with_fallback"
    SDP_BACKEND_DESC = sdp_desc

    logfile = None
    if master_process:
        os.makedirs(args.out_dir, exist_ok=True)
        logfile = os.path.join(args.out_dir, f"{args.run_id}.txt")
        print(logfile, flush=True)

    def log0(msg: str, console: bool = True) -> None:
        if not master_process:
            return
        if console:
            print(msg, flush=True)
        if logfile is not None:
            with open(logfile, "a", encoding="utf-8") as f:
                print(msg, file=f)

    log0(code, console=False)
    log0("=" * 100, console=False)
    log0(f"Running Python {sys.version}", console=False)
    log0(f"Running PyTorch {torch.__version__}", console=False)
    log0(
        subprocess.run(["nvidia-smi"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=False).stdout,
        console=False,
    )
    log0("=" * 100, console=False)

    # -----------------------------
    # SEEDING
    # -----------------------------
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)

    # -----------------------------
    # TOKENIZER + VALIDATION METRIC SETUP
    # -----------------------------
    if not args.tokenizer_path.endswith(".model"):
        raise ValueError(f"Need a SentencePiece .model file, got {args.tokenizer_path}")
    sp = spm.SentencePieceProcessor(model_file=args.tokenizer_path)
    if int(sp.vocab_size()) != args.vocab_size:
        raise ValueError(
            f"VOCAB_SIZE={args.vocab_size} != tokenizer vocab_size={int(sp.vocab_size())}"
        )
    dataset_dir = Path(args.data_path).resolve()
    actual_train_files = len(list(dataset_dir.glob("fineweb_train_*.bin")))
    val_tokens = load_validation_tokens(
        args.val_files, args.train_seq_len, max_tokens=args.max_val_tokens
    )
    base_bytes_lut, has_leading_space_lut, is_boundary_token_lut = build_sentencepiece_luts(
        sp, args.vocab_size, device
    )
    log0(f"val_bpb:enabled tokenizer_kind=sentencepiece tokenizer_path={args.tokenizer_path}")
    log0(f"train_loader:dataset:{dataset_dir.name} train_shards:{actual_train_files}")
    log0(f"val_loader:shards pattern={args.val_files} tokens:{val_tokens.numel() - 1}")
    log0(
        f"config:sliding_window_eval={args.sliding_window_eval} eval_stride={args.eval_stride} "
        f"fp16_embed_passthrough={args.fp16_embed_passthrough} "
        f"parallel_residual={args.parallel_residual} start={args.parallel_residual_start} "
        f"qk_gain_init={args.qk_gain_init} tuned_lr={args.tuned_lr}"
    )
    log0(
        f"lr_config:matrix_lr={args.matrix_lr} warmdown_iters={args.warmdown_iters} "
        f"tied_embed_lr={args.tied_embed_lr}"
    )

    # -----------------------------
    # MODEL + OPTIMIZER SETUP
    # -----------------------------
    base_model = GPT(
        vocab_size=args.vocab_size,
        num_layers=args.num_layers,
        model_dim=args.model_dim,
        num_heads=args.num_heads,
        num_kv_heads=args.num_kv_heads,
        mlp_mult=args.mlp_mult,
        tie_embeddings=args.tie_embeddings,
        tied_embed_init_std=args.tied_embed_init_std,
        logit_softcap=args.logit_softcap,
        rope_base=args.rope_base,
        qk_gain_init=args.qk_gain_init,
        parallel_residual=args.parallel_residual,
        parallel_residual_start=args.parallel_residual_start,
    ).to(device).bfloat16()
    for module in base_model.modules():
        if isinstance(module, CastedLinear):
            module.float()
    restore_low_dim_params_to_fp32(base_model)
    if use_compile:
        try:
            compiled_model = torch.compile(base_model, dynamic=False, fullgraph=True)
            model: nn.Module = DDP(compiled_model, device_ids=[local_rank], broadcast_buffers=False) if distributed else compiled_model
        except Exception as exc:
            print(f"[warn] torch.compile(model) unavailable, falling back to eager: {exc}", flush=True)
            use_compile = False
    if not use_compile:
        model = DDP(base_model, device_ids=[local_rank], broadcast_buffers=False) if distributed else base_model

    # 参数分组：矩阵参数走 Muon，嵌入/标量走 Adam
    block_named_params = list(base_model.blocks.named_parameters())
    matrix_params = [
        p
        for name, p in block_named_params
        if p.ndim == 2 and not any(pat in name for pat in CONTROL_TENSOR_NAME_PATTERNS)
    ]
    scalar_params = [
        p
        for name, p in block_named_params
        if p.ndim < 2 or any(pat in name for pat in CONTROL_TENSOR_NAME_PATTERNS)
    ]
    if base_model.skip_weights.numel() > 0:
        scalar_params.append(base_model.skip_weights)
    token_lr = args.tied_embed_lr if args.tie_embeddings else args.embed_lr
    optimizer_tok = torch.optim.Adam(
        [{"params": [base_model.tok_emb.weight], "lr": token_lr, "base_lr": token_lr}],
        betas=(args.beta1, args.beta2),
        eps=args.adam_eps,
        fused=True,
    )
    optimizer_muon = Muon(
        matrix_params,
        lr=args.matrix_lr,
        momentum=args.muon_momentum,
        backend_steps=args.muon_backend_steps,
    )
    for group in optimizer_muon.param_groups:
        group["base_lr"] = args.matrix_lr
    optimizer_scalar = torch.optim.Adam(
        [{"params": scalar_params, "lr": args.scalar_lr, "base_lr": args.scalar_lr}],
        betas=(args.beta1, args.beta2),
        eps=args.adam_eps,
        fused=True,
    )
    optimizers: list[torch.optim.Optimizer] = [optimizer_tok, optimizer_muon, optimizer_scalar]
    if base_model.lm_head is not None:
        optimizer_head = torch.optim.Adam(
            [{"params": [base_model.lm_head.weight], "lr": args.head_lr, "base_lr": args.head_lr}],
            betas=(args.beta1, args.beta2),
            eps=args.adam_eps,
            fused=True,
        )
        optimizers.insert(1, optimizer_head)

    n_params = sum(p.numel() for p in base_model.parameters())
    log0(f"model_params:{n_params}")
    # 记录并行残差实际启用的层数。若为 0，说明 start >= num_layers，
    # 该开关等于没开——必须显式暴露，否则消融实验会得出「无影响」的错误结论。
    n_parallel = sum(1 for b in base_model.blocks if b.parallel)
    log0(f"parallel_residual_enabled_layers:{n_parallel}/{args.num_layers} start:{args.parallel_residual_start}")
    if args.parallel_residual and n_parallel == 0:
        log0(
            f"WARNING: PARALLEL_RESIDUAL=1 but start={args.parallel_residual_start} >= "
            f"num_layers={args.num_layers}; NO layer actually uses parallel residual. "
            f"Set PARALLEL_RESIDUAL_START < NUM_LAYERS for this experiment to test anything."
        )
    log0(f"world_size:{world_size} grad_accum_steps:{grad_accum_steps}")
    log0("sdp_backends:" + SDP_BACKEND_DESC)

    # 探测 fused GQA 是否可用，决定走fused 还是手动展开路径
    head_dim_probe = args.model_dim // args.num_heads
    if GQA_IMPL == "auto":
        GQA_IMPL = (
            "fused"
            if probe_fused_gqa(device, args.num_heads, args.num_kv_heads, head_dim_probe)
            else "expand"
        )
    log0(f"gqa_impl:{GQA_IMPL}")
    log0(f"attention_mode:gqa num_heads:{args.num_heads} num_kv_heads:{args.num_kv_heads}")
    log0(
        f"tie_embeddings:{args.tie_embeddings} embed_lr:{token_lr} "
        f"matrix_lr:{args.matrix_lr} scalar_lr:{args.scalar_lr}"
    )
    log0(
        f"train_batch_tokens:{args.train_batch_tokens} train_seq_len:{args.train_seq_len} "
        f"iterations:{args.iterations} warmup_steps:{args.warmup_steps} "
        f"max_wallclock_seconds:{args.max_wallclock_seconds:.3f}"
    )
    log0(f"seed:{args.seed}")

    # -----------------------------
    # DATA LOADER + WARMUP
    # -----------------------------
    train_loader = DistributedTokenLoader(args.train_files, rank, world_size, device)

    def zero_grad_all() -> None:
        for opt in optimizers:
            opt.zero_grad(set_to_none=True)

    max_wallclock_ms = 1000.0 * args.max_wallclock_seconds if args.max_wallclock_seconds > 0 else None

    def lr_mul(step: int, elapsed_ms: float) -> float:
        """线性 warmdown：越接近时间上限，LR 越接近 0。

        用「时间」而非「步数」估算剩余时间，这样即使实际步数比预期少，
        LR 也能在预算耗尽前平滑归零，而不是在最后几步还在用满 LR 抖动。
        """
        if args.warmdown_iters <= 0:
            return 1.0
        if max_wallclock_ms is None:
            warmdown_start = max(args.iterations - args.warmdown_iters, 0)
            return (
                max((args.iterations - step) / max(args.warmdown_iters, 1), 0.0)
                if warmdown_start <= step < args.iterations
                else 1.0
            )
        step_ms = elapsed_ms / max(step, 1)
        warmdown_ms = args.warmdown_iters * step_ms
        remaining_ms = max(max_wallclock_ms - elapsed_ms, 0.0)
        return remaining_ms / max(warmdown_ms, 1e-9) if remaining_ms <= warmdown_ms else 1.0

    # Warmup：先跑几步把 compile/优化器路径都跑通，再把权重和优化器状态
    # 还原到真正的初始值，保证计时区间里统计的是真实训练。
    if args.warmup_steps > 0:
        initial_model_state = {n_: t.detach().cpu().clone() for n_, t in base_model.state_dict().items()}
        initial_optimizer_states = [copy.deepcopy(o.state_dict()) for o in optimizers]
        model.train()
        for warmup_step in range(args.warmup_steps):
            zero_grad_all()
            for micro_step in range(grad_accum_steps):
                if distributed:
                    model.require_backward_grad_sync = micro_step == grad_accum_steps - 1
                x, y = train_loader.next_batch(args.train_batch_tokens, args.train_seq_len, grad_accum_steps)
                with torch.autocast(device_type="cuda", dtype=torch.bfloat16, enabled=True):
                    warmup_loss = model(x, y)
                (warmup_loss * grad_scale).backward()
            for opt in optimizers:
                opt.step()
            zero_grad_all()
            log0(f"warmup_step:{warmup_step + 1}/{args.warmup_steps}", console=warmup_step == 0)
        base_model.load_state_dict(initial_model_state, strict=True)
        for opt, state in zip(optimizers, initial_optimizer_states, strict=True):
            opt.load_state_dict(state)
        zero_grad_all()
        if distributed:
            model.require_backward_grad_sync = True
        train_loader = DistributedTokenLoader(args.train_files, rank, world_size, device)

    # -----------------------------
    # MAIN TRAINING LOOP
    # -----------------------------
    training_time_ms = 0.0
    stop_after_step: int | None = None
    torch.cuda.synchronize()
    t0 = time.perf_counter()

    step = 0
    while True:
        last_step = step == args.iterations or (stop_after_step is not None and step >= stop_after_step)

        should_validate = last_step or (args.val_loss_every > 0 and step > 0 and step % args.val_loss_every == 0)
        if should_validate:
            torch.cuda.synchronize()
            training_time_ms += 1000.0 * (time.perf_counter() - t0)
            # 训练中用便宜的分块评估看趋势，最终分数用滑窗评估
            val_loss, val_bpb = eval_val_chunked(
                args, model, rank, world_size, device, grad_accum_steps,
                val_tokens, base_bytes_lut, has_leading_space_lut, is_boundary_token_lut,
            )
            log0(
                f"step:{step}/{args.iterations} val_loss:{val_loss:.4f} val_bpb:{val_bpb:.4f} "
                f"train_time:{training_time_ms:.0f}ms step_avg:{training_time_ms / max(step, 1):.2f}ms"
            )
            torch.cuda.synchronize()
            t0 = time.perf_counter()

        if last_step:
            if stop_after_step is not None and step < args.iterations:
                log0(
                    f"stopping_early: wallclock_cap train_time:{training_time_ms:.0f}ms step:{step}/{args.iterations}"
                )
            break

        elapsed_ms = training_time_ms + 1000.0 * (time.perf_counter() - t0)
        scale = lr_mul(step, elapsed_ms)
        zero_grad_all()
        train_loss = torch.zeros((), device=device)
        for micro_step in range(grad_accum_steps):
            if distributed:
                model.require_backward_grad_sync = micro_step == grad_accum_steps - 1
            x, y = train_loader.next_batch(args.train_batch_tokens, args.train_seq_len, grad_accum_steps)
            with torch.autocast(device_type="cuda", dtype=torch.bfloat16, enabled=True):
                loss = model(x, y)
            train_loss += loss.detach()
            (loss * grad_scale).backward()
        train_loss /= grad_accum_steps

        # Muon momentum 从 0.85 线性升到 0.95：训练早期梯度噪声大，
        # 低动量更稳；后期梯度方向稳定，高动量降噪。
        frac = min(step / args.muon_momentum_warmup_steps, 1.0) if args.muon_momentum_warmup_steps > 0 else 1.0
        muon_momentum = (1 - frac) * args.muon_momentum_warmup_start + frac * args.muon_momentum
        for group in optimizer_muon.param_groups:
            group["momentum"] = muon_momentum

        for opt in optimizers:
            for group in opt.param_groups:
                group["lr"] = group["base_lr"] * scale

        if args.grad_clip_norm > 0:
            torch.nn.utils.clip_grad_norm_(base_model.parameters(), args.grad_clip_norm)
        for opt in optimizers:
            opt.step()
        zero_grad_all()

        step += 1
        approx_training_time_ms = training_time_ms + 1000.0 * (time.perf_counter() - t0)
        should_log_train = (
            args.train_log_every > 0
            and (step <= 10 or step % args.train_log_every == 0 or stop_after_step is not None)
        )
        if should_log_train:
            log0(
                f"step:{step}/{args.iterations} train_loss:{train_loss.item():.4f} "
                f"train_time:{approx_training_time_ms:.0f}ms step_avg:{approx_training_time_ms / step:.2f}ms"
            )

        reached_cap = max_wallclock_ms is not None and approx_training_time_ms >= max_wallclock_ms
        if distributed and max_wallclock_ms is not None:
            reached_cap_tensor = torch.tensor(int(reached_cap), device=device)
            dist.all_reduce(reached_cap_tensor, op=dist.ReduceOp.MAX)
            reached_cap = bool(reached_cap_tensor.item())
        if stop_after_step is None and reached_cap:
            stop_after_step = step

    log0(
        f"peak memory allocated: {torch.cuda.max_memory_allocated() // 1024 // 1024} MiB "
        f"reserved: {torch.cuda.max_memory_reserved() // 1024 // 1024} MiB"
    )
    total_train_tokens = step * args.train_batch_tokens
    log0(f"total_train_tokens:{total_train_tokens}")

    # -----------------------------
    # SERIALIZATION + QUANTIZATION
    # -----------------------------
    if master_process:
        torch.save(base_model.state_dict(), "final_model.pt")
        model_bytes = os.path.getsize("final_model.pt")
        code_bytes = len(code.encode("utf-8"))
        log0(f"Serialized model: {model_bytes} bytes")
        log0(f"Code size: {code_bytes} bytes")
        log0(f"Total submission size: {model_bytes + code_bytes} bytes")

    quant_obj, quant_stats = quantize_state_dict_int8(
        base_model.state_dict(), fp16_passthrough=args.fp16_embed_passthrough
    )
    quant_buf = io.BytesIO()
    torch.save(quant_obj, quant_buf)
    quant_raw = quant_buf.getvalue()
    quant_blob = zlib.compress(quant_raw, level=9)
    quant_raw_bytes = len(quant_raw)
    if master_process:
        with open("final_model.int8.ptz", "wb") as f:
            f.write(quant_blob)
        quant_file_bytes = os.path.getsize("final_model.int8.ptz")
        code_bytes = len(code.encode("utf-8"))
        ratio = quant_stats["baseline_tensor_bytes"] / max(quant_stats["int8_payload_bytes"], 1)
        log0(
            f"Serialized model int8+zlib: {quant_file_bytes} bytes "
            f"(payload:{quant_stats['int8_payload_bytes']} raw_torch:{quant_raw_bytes} payload_ratio:{ratio:.2f}x)"
        )
        log0(
            f"fp16_passthrough_bytes:{quant_stats['fp16_passthrough_bytes']} "
            f"param_count:{quant_stats['param_count']}"
        )
        log0(f"Total submission size int8+zlib: {quant_file_bytes + code_bytes} bytes")
        # 16MB 硬约束自检：官方是十进制16,000,000 字节
        total_bytes = quant_file_bytes + code_bytes
        if total_bytes > 16_000_000:
            log0(f"ARTIFACT_SIZE_VIOLATION: {total_bytes} > 16,000,000")
        else:
            log0(f"ARTIFACT_SIZE_OK: {total_bytes} <= 16,000,000 (headroom {16_000_000 - total_bytes})")

    # -----------------------------
    # ROUNDTRIP EVALUATION（真正的榜单分数）
    # 量化 → 解压 → 重新加载 → 评估。这一步的数字才是 submission 里的分数。
    # -----------------------------
    if distributed:
        dist.barrier()
    with open("final_model.int8.ptz", "rb") as f:
        quant_blob_disk = f.read()
    quant_state = torch.load(io.BytesIO(zlib.decompress(quant_blob_disk)), map_location="cpu")
    base_model.load_state_dict(dequantize_state_dict_int8(quant_state), strict=True)

    torch.cuda.synchronize()
    t_qeval = time.perf_counter()
    if args.sliding_window_eval:
        q_val_loss, q_val_bpb = eval_val_sliding(
            args, base_model, rank, world_size, device,
            val_tokens, base_bytes_lut, has_leading_space_lut, is_boundary_token_lut,
        )
        eval_mode = f"sliding_stride{args.eval_stride}"
    else:
        q_val_loss, q_val_bpb = eval_val_chunked(
            args, model, rank, world_size, device, grad_accum_steps,
            val_tokens, base_bytes_lut, has_leading_space_lut, is_boundary_token_lut,
        )
        eval_mode = "chunked"
    torch.cuda.synchronize()
    eval_time_ms = 1000.0 * (time.perf_counter() - t_qeval)
    log0(
        f"final_int8_zlib_roundtrip eval_mode:{eval_mode} val_loss:{q_val_loss:.4f} "
        f"val_bpb:{q_val_bpb:.4f} eval_time:{eval_time_ms:.0f}ms"
    )
    log0(f"final_int8_zlib_roundtrip_exact val_loss:{q_val_loss:.8f} val_bpb:{q_val_bpb:.8f}")

    # 同时记录 chunked 分数，便于量化「滑窗评估」这一项的独立贡献
    if args.sliding_window_eval:
        torch.cuda.synchronize()
        t_ceval = time.perf_counter()
        c_val_loss, c_val_bpb = eval_val_chunked(
            args, model, rank, world_size, device, grad_accum_steps,
            val_tokens, base_bytes_lut, has_leading_space_lut, is_boundary_token_lut,
        )
        torch.cuda.synchronize()
        log0(
            f"reference_chunked_eval val_loss:{c_val_loss:.8f} val_bpb:{c_val_bpb:.8f} "
            f"eval_time:{1000.0 * (time.perf_counter() - t_ceval):.0f}ms"
        )
        log0(f"sliding_gain_bpb:{c_val_bpb - q_val_bpb:.8f}")

    if master_process:
        submission = {
            "author": "07Meteorain",
            "github_id": "07Meteorain",
            "name": args.run_id,
            "blurb": (
                "Baseline + sliding-window eval + fp16 embedding passthrough + "
                "parallel residuals + QK-gain + tuned LR warmdown."
            ),
            "date": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "val_loss": q_val_loss,
            "val_bpb": q_val_bpb,
            "eval_mode": eval_mode,
            "seed": args.seed,
            "steps": step,
            "total_train_tokens": total_train_tokens,
            "val_tokens_used": int(val_tokens.numel() - 1),
            "val_set_is_full_official": args.max_val_tokens == 0,
            "train_time_ms": round(training_time_ms, 1),
            "eval_time_ms": round(eval_time_ms, 1),
            "artifact_bytes_total": quant_file_bytes + len(code.encode("utf-8")),
            "artifact_bytes_code": len(code.encode("utf-8")),
            "artifact_bytes_model": quant_file_bytes,
            "config": {
                "vocab_size": args.vocab_size,
                "num_layers": args.num_layers,
                "model_dim": args.model_dim,
                "num_heads": args.num_heads,
                "num_kv_heads": args.num_kv_heads,
                "mlp_mult": args.mlp_mult,
                "tie_embeddings": args.tie_embeddings,
                "qk_gain_init": args.qk_gain_init,
                "matrix_lr": args.matrix_lr,
                "warmdown_iters": args.warmdown_iters,
                "tied_embed_lr": args.tied_embed_lr,
                "sliding_window_eval": args.sliding_window_eval,
                "eval_stride": args.eval_stride,
                "fp16_embed_passthrough": args.fp16_embed_passthrough,
                "parallel_residual": args.parallel_residual,
                "parallel_residual_start": args.parallel_residual_start,
                "tuned_lr": args.tuned_lr,
            },
            "hardware": {
                "gpu_name": torch.cuda.get_device_name(0),
                "world_size": world_size,
            },
        }
        with open(os.path.join(args.out_dir, f"{args.run_id}_submission.json"), "w", encoding="utf-8") as f:
            json.dump(submission, f, indent=2, ensure_ascii=False)
        log0("submission_json_written:" + os.path.join(args.out_dir, f"{args.run_id}_submission.json"))

    if distributed:
        dist.destroy_process_group()


if __name__ == "__main__":
    main()